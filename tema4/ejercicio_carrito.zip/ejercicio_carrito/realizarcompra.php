<?php
setcookie("carrito[ref1]", '', time()-100);
setcookie("carrito[ref2]", '', time()-100);
setcookie("carrito[ref3]", '', time()-100);


?>

<html>
<head>
<meta charset="utf-8">
<title>Compra realizada</title>
</head>

<body>
<h1>Compra realizada</h1>
<br>
<p>Gracias por su compra.</p>
<br>
<a href="tienda.php"><button>Tienda</button></a>

</body>
</html>
